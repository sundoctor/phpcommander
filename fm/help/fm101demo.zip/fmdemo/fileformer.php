<?php
class TFileFormer {
var $rootdir = '';
var $params  = array();
var $cache   = array();
function TFileFormer($setroot = '.') {
$this->rootdir = $setroot;
}
function setItem($name, $value) {
$this->params[$name] = $value;
}
function getItem($name) {
if (isset($this->params[$name])) {
return $this->params[$name];
}
return null;
}
function getViewItem($name) {
$v = $this->getItem($name);
if ($v!==null) {
if (is_array($v))
return join('', $v);
return $v;
}
return '';
}
function setItems($attrs) {
while(list($k,$v) = each($attrs)) {
$this->params[$k] = $v;
}
}
function getItems($attrs) {
$result = array();
foreach($attrs as $k) {
if (isset($this->params[$k]))
$result[$k] = $this->params[$k];
}
return $result;
}
function clear() {
$this->params = array();
$this->cache  = array();
}
function transform($filename) {
$usefile = filename($filename, $this->rootdir);
$test = isset($this->cache[$usefile]) || file_exists($usefile);
if (isset($this->cache[$usefile])) {
$s = $this->cache[$usefile];
}
else if (file_exists($usefile)) {
$s = join('', file($usefile));
$this->cache[$usefile] = $s;
}
if ($test) {
$search  = "/<!--#(.*?)-->/e";
$s = preg_replace($search, "TFileFormer::transform('\\1')", $s);
$search  = "/<!--\\$(.*?)-->/e";
$s = preg_replace($search, "TFileFormer::getViewItem('\\1')", $s);
return $s;
}
return '';
}}
class TTextFormer {
var $rootdir     = '';
var $filecontent = array();
var $out         = array();
function TTextFormer($setroot = '.') {
$this->rootdir = $setroot;
}
function clear() {
$this->file       = array();
$this->out        = array();
}
function load($filename="") {
$usefile = filename($filename, $this->rootdir);
$filecontent = '';
if (file_exists($usefile)) {
$filecontent = join('', file($usefile));
}
$reg = "/<!--\+(\w+?)\+-->/ims";
if (preg_match_all($reg, $filecontent, $m)) {
$matches = $m[1];
foreach ($matches as $v) {
$reg = "/<!--\+$v\+-->(.*)<!--=$v=-->/ims";
if (preg_match_all($reg, $filecontent, $m))
$this->file[$v] = $m[1][0];
}}}
function post($outhandle, $filehandle, $vars=array()) {
$search  = "/<!--\\$(.*?)-->/";
$s = '';
if (isset($this->file[$filehandle]))
$s = $this->file[$filehandle];
if (preg_match_all($search, $s, $matches)!==false) {
foreach($matches[1] as $v) {
$search = "<!--$".$v."-->";
if (isset($vars[$v]))
$s = str_replace($search, $vars[$v], $s);
else
$s = str_replace($search, '', $s);
}}
if (!isset($this->out[$outhandle]))
$this->out[$outhandle] = array();
$this->out[$outhandle][] = $s;
}
function getText($n = '') {
$result = '';
if ($n=='')
foreach($this->out as $k=>$v) {
$result .= join('',$this->out[$k]);
}else
$result = join('',$this->out[$n]);
return $result;
}}
function filename($filename, $rootdir='.') {
$filename = trim($filename);
if (substr($filename, 0, 1) != "/")
$new_filename = $rootdir.'/'.$filename;
else
$new_filename = $filename;
return $new_filename;
}
?>