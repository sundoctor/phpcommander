<?php
include("config.inc.php");
include("quotesoff.inc.php");
class TFileFormer {
var $rootdir = '';
var $params  = array();
var $cache   = array();
function TFileFormer($setroot = '.') {
$this->rootdir = $setroot;
}
function setItem($name, $value) {
$this->params[$name] = $value;
}
function getItem($name) {
if (isset($this->params[$name])) {
return $this->params[$name];
}
return null;
}
function getViewItem($name) {
$v = $this->getItem($name);
if ($v!==null) {
if (is_array($v))
return join('', $v);
return $v;
}
return '';
}
function setItems($attrs) {
while(list($k,$v) = each($attrs)) {
$this->params[$k] = $v;
}
}
function getItems($attrs) {
$result = array();
foreach($attrs as $k) {
if (isset($this->params[$k]))
$result[$k] = $this->params[$k];
}
return $result;
}
function clear() {
$this->params = array();
$this->cache  = array();
}
function transform($filename) {
$usefile = filename($filename, $this->rootdir);
$test = isset($this->cache[$usefile]) || file_exists($usefile);
if (isset($this->cache[$usefile])) {
$s = $this->cache[$usefile];
}
else if (file_exists($usefile)) {
$s = join('', file($usefile));
$this->cache[$usefile] = $s;
}
if ($test) {
$search  = "/<!--#(.*?)-->/e";
$s = preg_replace($search, "TFileFormer::transform('\\1')", $s);
$search  = "/<!--\\$(.*?)-->/e";
$s = preg_replace($search, "TFileFormer::getViewItem('\\1')", $s);
return $s;
}
return '';
}}
class TTextFormer {
var $rootdir     = '';
var $filecontent = array();
var $out         = array();
function TTextFormer($setroot = '.') {
$this->rootdir = $setroot;
}
function clear() {
$this->file       = array();
$this->out        = array();
}
function load($filename="") {
$usefile = filename($filename, $this->rootdir);
$filecontent = '';
if (file_exists($usefile)) {
$filecontent = join('', file($usefile));
}
$reg = "/<!--\+(\w+?)\+-->/ims";
if (preg_match_all($reg, $filecontent, $m)) {
$matches = $m[1];
foreach ($matches as $v) {
$reg = "/<!--\+$v\+-->(.*)<!--=$v=-->/ims";
if (preg_match_all($reg, $filecontent, $m))
$this->file[$v] = $m[1][0];
}}}
function post($outhandle, $filehandle, $vars=array()) {
$search  = "/<!--\\$(.*?)-->/";
$s = '';
if (isset($this->file[$filehandle]))
$s = $this->file[$filehandle];
if (preg_match_all($search, $s, $matches)!==false) {
foreach($matches[1] as $v) {
$search = "<!--$".$v."-->";
if (isset($vars[$v]))
$s = str_replace($search, $vars[$v], $s);
else
$s = str_replace($search, '', $s);
}}
if (!isset($this->out[$outhandle]))
$this->out[$outhandle] = array();
$this->out[$outhandle][] = $s;
}
function getText($n = '') {
$result = '';
if ($n=='')
foreach($this->out as $k=>$v) {
$result .= join('',$this->out[$k]);
}else
$result = join('',$this->out[$n]);
return $result;
}}
function filename($filename, $rootdir='.') {
$filename = trim($filename);
if (substr($filename, 0, 1) != "/")
$new_filename = $rootdir.'/'.$filename;
else
$new_filename = $filename;
return $new_filename;
}
session_start();
srand((double)microtime()*1000000);
if (!isset($_SESSION['registered'])) {
$_SESSION['registered'] = false;
}
include("common.inc.php");
include('pwd.lib.php');
$pwdMan = new TPwd();
$reset = isset($_REQUEST['reset'])? true:false;
$sesvar = array(
);
foreach($sesvar as $k=>$v) {
if (!isset($_SESSION[$k]) || $reset) {
$_SESSION[$k] = $v;
$$k = $v;
}}
$sorts = array(
'nameaz', 'nameza',
'extaz',  'extza',
'sizeaz', 'sizeza',
'dateaz', 'dateza'
);
$now = date('Y-m-d H:i:s');
$freespace = number_format(diskfreespace("/"));
$sort = isset($_REQUEST['sort'])? $_REQUEST['sort'] : 'nameaz';
if (!in_array($sort, $sorts)) $sort = 'nameaz';
$sortdir = substr($sort,-2);
$sortord = substr($sort,0,strlen($sort)-2);
if ($sortdir!='az' && $sortdir!='za') $sortdir = 'az';
$path = isset($_REQUEST['path'])? ($_REQUEST['path']) : $STARTDIR;
$path  = strtr($path,'\\','/');
if ($BASEPATH!='' && strpos($path,$BASEPATH)!==0) $path = $BASEPATH;
while (!file_exists($path)) {
$p = strrpos($path,'/');
if ($p===false) break;
$path = substr($path,0,$p);
}
$errCode = 0;
if (isset($_REQUEST['error']))
setErrorCode(substr($_REQUEST['error'],0,2));
$errMsg = array(
0  => '',
1  => 'File not found!',
2  => 'File already exists!',
3  => 'Directory read error!',
4  => 'Bad file name!',
5  => 'File too large!',
6  => 'File not writable!'
);
$cmd = isset($_REQUEST['cmd'])? substr($_REQUEST['cmd'],0,10) : 'list';
if (!$_SESSION['registered'] && $cmd!='logon') $cmd = 'login';
if ($BASEPATH!='' && strpos($path,$BASEPATH)!==0) {
$cmd = 'login';
}
foreach($sesvar as $k=>$v) {
$$k = $_SESSION[$k];
if (isset($_REQUEST[$k])) {
$$k = $_REQUEST[$k];
$_SESSION[$k] = $$k;
}}
$cmds = array(
'login',
'logon',
'logout',
'list',
'upload'
);
$OUTPUT = '';
$LOCATION = '';
if (in_array($cmd,$cmds) && file_exists('./'.$cmd.'.cmd.php'))
include('./'.$cmd.'.cmd.php');
if ($OUTPUT!='') {
echo $OUTPUT;
exit;
}
if ($LOCATION!='') {
header("Location: $LOCATION");
exit;
}
$html = new TFileFormer('.');
$html->setItems(array(
"title"          => join(' ~ ',$TITLE),
"description"    => $KEYWORDS,
"keywords"       => $DESCRIPTION,
"content"        => $CONTENT
));
$OUTPUT = $html->transform($TEMPLATE);
echo $OUTPUT;
?>