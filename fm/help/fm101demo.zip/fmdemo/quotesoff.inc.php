<?php
$SAVEVARS = array(
'GLOBALS',
'ROOT',
'PATH',
'CHARSET',
'TITLE',
'DESCRIPTION',
'KEYWORDS',
'CONTENT',
'TEMPLATE',
'CONST',
'BLOCKED',
'MYREFERS',
'NOW',
'TIMEPOINT',
'TIMEPOINT_START',
'COLORS',
'BASEPATH',
'STARTDIR',
'MAXVIEWSIZE',
'WINDOWS',
'WINDRIVES'
);
function stripVars(&$var) {
global $SAVEVARS;
if (is_array($var)) {
foreach($var as $k=>$v) {
if ($k!='GLOBALS' && $k!='_FILES' && !in_array($k, $SAVEVARS)) {
stripVars($var[$k]);
}}} else {
$var = stripslashes($var);
}}
if (get_magic_quotes_gpc()) stripVars($GLOBALS);
function clearGlobals(&$var) {
global $SAVEVARS;
if (is_array($var)) {
foreach($var as $k=>$v) {
if (!in_array($k, $SAVEVARS)) {
if (isset($GLOBALS[$k]))
    unset($GLOBALS[$k]);
}}}}
clearGlobals($_REQUEST);
clearGlobals($_SESSION);
clearGlobals($_ENV);
clearGlobals($_SERVER);
?>