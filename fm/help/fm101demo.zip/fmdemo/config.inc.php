<?php
define('VERSION', '1');
define('ACTIVE', true);
$TIMEPOINT = time();
$NOW = date("Y-m-d H:i:s");
$COLORS = array(
    'exe' => '#FF0000',
    'com' => '#FF0000',
    'bat' => '#FF0000',
    'php' => '#6A179B',
    'txt' => '#696969',
    'gif' => '#008000',
    'jpg' => '#008000',
    'png' => '#008000'
);
$BASEPATH = '';
$STARTDIR = realpath('..');
$MAXVIEWSIZE = 1024*100*3;
$WINDOWS = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN'? true: false;
$WINDRIVES = array();
$CHARSET = 'windows-1251';
$TITLE = array('FM File Manager v1.01 DEMO');
$KEYWORDS = '';
$DESCRIPTION = '';
$CONTENT = '';
$TEMPLATE = 'page.html';
$CONST = array(
    'email'    => 'ubit@mail.ru',
    'site'     => 'artix-hit.narod.ru',
    'phone'    => '8-916-115-78-42',
    'author'   => '(C) ����� ��������� aka Artix'
);
$ROOT = dirname(__FILE__);
$_DOCUMENT_ROOT = isset($_SERVER['DOCUMENT_ROOT'])?
$_SERVER['DOCUMENT_ROOT'] : $ROOT;
$_PATH = substr($ROOT,strlen($_DOCUMENT_ROOT));
$_PATH = str_replace('\\','/',$_PATH);
$PATH = $_PATH;
unset($_DOCUMENT_ROOT);
unset($_PATH);
error_reporting(E_ALL);
set_time_limit(30);
set_magic_quotes_runtime(0);
ini_set("magic_quotes_gpc","Off");
ini_set("magic_quotes_runtime","Off");
ini_set("magic_quotes_sybase","Off");
$BLOCKED = array(
    '255.255.255.255'
);
$MYREFERERS = array(
    'http://localhost',
    'http://127.0.0.1'
);
function getmicrotime() {
    list($usec, $sec) = explode(' ', microtime());
    return ((float)$usec + (float)$sec);
}
$TIMEPOINT_START = getmicrotime();
?>