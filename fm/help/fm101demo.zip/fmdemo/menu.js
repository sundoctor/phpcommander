<SCRIPT LANGUAGE="JavaScript">
<!--

var block = false;

var demoMsg = '� ����-������ ��� ������� �����������. '+
              '����� ��� ������� ����������� - ������ ���������. E-mail ��� �����: ubit@mail.ru';

function cmdRefresh() {
    document.listform.cmd.value = 'list';
    document.listform.submit();
}

function CountSelected() {
    var selected = 0;
    var filelist = document.listform.elements['file[]'];
    if (filelist!=null) {
        if (filelist.length)
            for(var i=0;i<filelist.length;i++)
                selected += filelist[i].checked?1:0;
        else
            selected = filelist.checked?1:0;
    }
    return selected;
}

function CheckOnlyOne() {
    if (CountSelected()!=1)
        return false;
    return true;
}

function cmdSelectAll() {
    var filelist = document.listform.elements['file[]'];
    if (filelist!=null) {
        if (filelist.length) {
            for(i=0;i<filelist.length;i++)
                filelist[i].checked = true;
        }
        else if (filelist.checked!=null)
            filelist.checked = true;
    }
}

function cmdSelectNone() {
    var filelist = document.listform.elements['file[]'];
    if (filelist!=null) {
        if (filelist.length) {
            for(var i=0;i<filelist.length;i++)
                filelist[i].checked = false;
        }
        else if (filelist.checked!=null)
            filelist.checked = false;
    }
}

function cmdNew() {
    alert(demoMsg);
    return;
}

function cmdView() {
    alert(demoMsg);
    return;
}

function cmdEdit() {
    alert(demoMsg);
    return;
}

function cmdCut() {
    alert(demoMsg);
    return;
}

function cmdCopy() {
    alert(demoMsg);
    return;
}

function cmdPaste() {
    alert(demoMsg);
    return;
}

function cmdClear() {
    alert(demoMsg);
    return;
}

function cmdRemove() {
    alert(demoMsg);
    return;
}

function cmdRemoveAll() {
    alert(demoMsg);
    return;
}

function cmdRemoveX() {
    alert(demoMsg);
    return;
}

function cmdAttr() {
    alert(demoMsg);
    return;
}

function cmdRename() {
    alert(demoMsg);
    return;
}

function cmdMakeDir() {
    alert(demoMsg);
    return;
}

function cmdSend() {
    alert(demoMsg);
    return;
}

function goUrl(url) {
    var sort = document.listform.elements['sort'].value;
    var newurl = 'index.php?cmd=list&sort='+sort+'&path='+url;
    document.location.href = newurl;
}

//-->
</SCRIPT>
