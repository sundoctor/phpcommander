<?
if (!defined('ACTIVE')) die(__FILE__);
$_SESSION['registered'] = false;
$LOCATION = 'index.php?cmd=list';
?>