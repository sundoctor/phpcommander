<?php
function getFileName($path, $filename) {
if (!is_string($filename)) return '';
if (is_dir($path.'/'.$filename)) return $filename;
$pos = strrpos($filename, ".");
if ($pos === false) return $filename;
return substr($filename,0,$pos);
}
function getFileExt($path, $filename) {
if (!is_string($filename)) return '';
if (is_dir($path.'/'.$filename)) return '[DIR]';
$pos = strrpos($filename, ".");
if ($pos === false) return '';
return substr($filename, $pos+1);
}
function getFileType($path, $filename) {
if (is_dir($path.'/'.$filename)) return 'D';
return 'F';
}
function getFileDate($path, $filename) {
return date("Y-m-d H:i:s", filemtime($path.'/'.$filename));
}
function getFileSize($path, $filename) {
return filesize($path.'/'.$filename);
}
function getTextPerm( $in_Perms ) {
if($in_Perms & 0x1000)
$sP = 'p';
elseif($in_Perms & 0x2000) $sP = 'c';
elseif($in_Perms & 0x4000) $sP = 'd';
elseif($in_Perms & 0x6000) $sP = 'b';
elseif($in_Perms & 0x8000) $sP = '-';
elseif($in_Perms & 0xA000) $sP = 'l';
elseif($in_Perms & 0xC000) $sP = 's';
else
$sP = 'u';
$sP .= (($in_Perms & 0x0100) ? 'r' : '-;') .
(($in_Perms & 0x0080) ? 'w' : '-') .
(($in_Perms & 0x0040) ? (($in_Perms & 0x0800) ? 's' : 'x' ) :
(($in_Perms & 0x0800) ? 'S' : '-'));
$sP .= (($in_Perms & 0x0020) ? 'r' : '-') .
(($in_Perms & 0x0010) ? 'w' : '-') .
(($in_Perms & 0x0008) ? (($in_Perms & 0x0400) ? 's' : 'x' ) :
(($in_Perms & 0x0400) ? 'S' : '-'));
$sP .= (($in_Perms & 0x0004) ? 'r' : '-') .
(($in_Perms & 0x0002) ? 'w' : '-') .
(($in_Perms & 0x0001) ? (($in_Perms & 0x0200) ? 't' : 'x' ) :
(($in_Perms & 0x0200) ? 'T' : '-'));
return $sP;
}
function getFilePerm($path, $filename) {
return fileperms($path.'/'.$filename);
}
function getFiles($path) {
$res = array();
if ($dir = @opendir($path)) {
while (false !== ($file = readdir($dir))) {
if ($file != '.')
$res[] = array(
'fullname' => $file,
'name' => getFileName($path, $file),
'ext'  => getFileExt($path, $file),
'type' => getFileType($path, $file),
'date' => getFileDate($path, $file),
'size' => getFileSize($path, $file),
'attr' => getTextPerm(getFilePerm($path, $file))
);
}
closedir($dir);
} else {
setErrorCode(3);
}
return $res;
}
function cmpTwoNames($a, $b) {
if ($a['name']==$b['name']) return 0;
if ($a['name']=='..') return -1;
if ($b['name']=='..') return 1;
return ($a['name'] < $b['name']) ? -1 : 1;
}
function cmpName ($a, $b) {
global $sortdir;
if ($a['type']!='D' && $b['type']!='D') {
if ($sortdir=='az')
return ($a['name'] < $b['name']) ? -1 : 1;
else
return ($a['name'] > $b['name']) ? -1 : 1;
}
else if ($a['type']=='D' && $b['type']=='D') {
return cmpTwoNames($a,$b);
}
else if ($a['type']=='D' && $b['type']!='D')
return -1;
else if ($a['type']!='D' && $b['type']=='D')
return 1;
}
function cmpExt($a, $b) {
global $sortdir;
if (($a['type']=='D' && $b['type']=='D') ||
($a['type']!='D' && $b['type']!='D')) {
if ($a['ext'] == $b['ext'])
return cmpTwoNames($a,$b);
if ($sortdir=='az')
return ($a['ext'] < $b['ext']) ? -1 : 1;
else
return ($a['ext'] > $b['ext']) ? -1 : 1;
}
else if ($a['type']=='D' && $b['type']!='D')
return -1;
else if ($a['type']!='D' && $b['type']=='D')
return 1;
}
function cmpSize($a, $b) {
global $sortdir;
if (($a['type']!='D' && $b['type']!='D') ||
($a['type']=='D' && $b['type']=='D')) {
if ($a['size'] == $b['size'])
return cmpTwoNames($a,$b);
if ($sortdir=='az')
return ($a['size'] < $b['size']) ? -1 : 1;
else
return ($a['size'] > $b['size']) ? -1 : 1;
}
else if ($a['type']=='D' && $b['type']!='D')
return -1;
else if ($a['type']!='D' && $b['type']=='D')
return 1;
}
function cmpDate($a, $b) {
global $sortdir;
if ($a['type']!='D' && $b['type']!='D') {
if ($a['date'] == $b['date'])
return cmpTwoNames($a,$b);
if ($sortdir=='az')
return ($a['date'] < $b['date']) ? -1 : 1;
else
return ($a['date'] > $b['date']) ? -1 : 1;
}
else if ($a['type']=='D' && $b['type']=='D') {
return cmpTwoNames($a,$b);
}
else if ($a['type']=='D' && $b['type']!='D')
return -1;
else if ($a['type']!='D' && $b['type']=='D')
return 1;
}
function color($str, $ext) {
global $COLORS;
if (isset($COLORS[$ext]))
return '<FONT COLOR="'.$COLORS[$ext].'">'.$str.'</FONT>';
return $str;
}
function file2html($path, $fileinfo) {
global $sort;
if ($fileinfo['type'] != 'D')
return $fileinfo['name'];
else {
$goto = $path."/".$fileinfo['fullname'];
if ($fileinfo['name']=='..') {
$a = split('[/\]',$path);
if (count($a)>0)
unset($a[count($a)-1]);
$goto = join('/',$a);
}
$html = '<A href="index.php?cmd=list&sort='.$sort.
'&path='.urlencode($goto).'">'.$fileinfo['name'].'</A>';
return $html;
}
}
function file2checkbox($fileinfo) {
if ($fileinfo['type'] != 'D')
return '<INPUT type="checkbox" name="file[]" value="1">';
if ($fileinfo['fullname']!='..')
return '<INPUT type="checkbox" name="file[]" value="2">';
return '&nbsp;&nbsp;&nbsp;&nbsp;';
}
function setErrorCode($newcode) {
global $errCode, $errMsg;
if (is_numeric($newcode) && $newcode>=0 && $newcode<count($errMsg)) {
if ($errCode==0) $errCode = $newcode;
} else {
$errCode = 0;
}}
function buildQuery($a) {
$result = array();
foreach ($a as $k=>$v) {
$result[] = "$k=$v";
}
return join('&',$result);
}
?>